A Integração Contínua é a prática de desenvolvimento de software que visa integrar mudanças frequentes do código em um repositório compartilhado pela equipe.  
As branches permitem que os desenvolvedores trabalhem em funcionalidades separadas, evitando interferência entre os códigos. Algumas de suas vantagens estão entre:  
-Facilitar o controle de versões
-Revisão do código
-Trabalhar em outras funcionalidades (Branch paralela)
Por conseguinte, o Pull Request é importante pois possibilita revisar e discutir o código antes de integrá-lo à branch principal, garantindo maior segurança, qualidade e colaboração no processo de desenvolvimento.  
